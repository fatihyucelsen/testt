<template>
  <div class="basket">
    <div class="logo">
      <Logo :width="200" />
    </div>

    <div class="basket-content">
      <div class="basket-header animate__animated animate__fadeInDown">
        <div class="title-container">
          <div class="title-icon">
            <BasketIcon :width="32" :height="32" :fill="'#ff8500'" />
          </div>
          <h1>Sepetim <span class="count">({{ basket?.count || 0 }})</span></h1>
          <div class="animated-line"></div>
        </div>
      </div>

      <div class="scrollable-content custom-scrollbar">
        <TransitionGroup 
          name="list" 
          tag="div" 
          class="basket-items"
        >
          <div v-for="product in basket?.products" 
               :key="product.index"
               class="basket-item animate__animated animate__fadeIn">
            <div class="item-image">
              <img :src="product.src" :alt="product.name" />
            </div>
            
            <div class="item-details">
              <div class="item-header">
                <h3>{{ product.name }}</h3>
                <div class="item-options">
                  <span class="option">
                    <span class="option-dot"></span>
                    Seçenek 1
                  </span>
                  <span class="option">
                    <span class="option-dot"></span>
                    Seçenek 2
                  </span>
                </div>
              </div>

              <div class="item-actions">
                <div class="quantity-controls">
                  <button @click="setQuantityMinus(product)" class="quantity-btn">
                    <Trash v-if="product.quantity == 1" 
                          :width="28" :height="28" 
                          :fill="'#ff4757'" />
                    <Minus v-else 
                           :width="28" :height="28" 
                           :fill="'#2d3436'" />
                  </button>

                  <span class="quantity">{{ product.quantity }}</span>

                  <button @click="setQuantityPlus(product)" class="quantity-btn">
                    <Plus :width="28" :height="28" :fill="'#2d3436'" />
                  </button>
                </div>

                <div class="price">
                  <span class="amount">{{ product.price }}</span>
                  <span class="currency">TL</span>
                </div>
              </div>
            </div>
          </div>
        </TransitionGroup>
      </div>

      <div class="fixed-bottom">
        <div class="basket-summary animate__animated animate__fadeInUp">
          <div class="summary-content">
            <div class="summary-item">
              <span>Ara Toplam</span>
              <span>{{ ((basket?.total || 0) * 0.92).toFixed(2) }} TL</span>
            </div>
            <div class="summary-item">
              <span>KDV (%8)</span>
              <span>{{ ((basket?.total || 0) * 0.08).toFixed(2) }} TL</span>
            </div>
            <div class="summary-total">
              <span>Toplam</span>
              <span>{{ (basket?.total || 0).toFixed(2) }} TL</span>
            </div>
          </div>
        </div>

        <div class="basket-footer animate__animated animate__fadeInUp">
          <button class="back-btn" @click="goMenu">
            <div class="btn-content">
              <ArrowLeft :width="24" :height="24" :fill="'#ff8500'" />
              <span>MENÜYE DÖN</span>
            </div>
            <div class="btn-shine"></div>
          </button>

          <button class="checkout-btn" @click="goPayment">
            <div class="btn-content">
              <div class="total">{{ (basket?.total || 0).toFixed(2) }} TL</div>
              <div class="separator"></div>
              <div class="text">
                <span>SİPARİŞİ TAMAMLA</span>
                <ArrowRight :width="24" :height="24" :fill="'#fff'" />
              </div>
            </div>
            <div class="btn-shine"></div>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useApplicationStore } from '@/stores/application'
import { storeToRefs } from 'pinia'

import Logo from '../components/icons/Logo.vue'
import BasketIcon from '../components/icons/Basket.vue'
import Minus from '../components/icons/Minus.vue'
import Plus from '../components/icons/Plus.vue'
import Trash from '../components/icons/Trash.vue'
import ArrowLeft from '../components/icons/ArrowLeft.vue'
import ArrowRight from '../components/icons/ArrowRight.vue'

const router = useRouter()
const applicationStore = useApplicationStore()
const { basket } = storeToRefs(applicationStore)
const { updateBasketTotals, removeBasketItem } = applicationStore

const setQuantityMinus = (product) => {
  if (product.quantity > 1) {
    product.quantity--
  } else {
    removeBasketItem(product)
  }
  updateBasketTotals()
}

const setQuantityPlus = (product) => {
  if (product.quantity > 0) {
    product.quantity++
  }
  updateBasketTotals()
}

const goMenu = () => {
  router.push({ name: 'menu' })
}

const goPayment = () => {
  router.push({ name: 'payment' })
}
</script>

<style scoped>
@import 'animate.css';

.basket {
  width: 100vw;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f8f9fa;
}

.logo {
  flex: 0 0 auto;
  background-color: #000;
  display: flex;
  justify-content: center;
  padding: 1rem 0;
}

.basket-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 1rem;
  gap: 1rem;
  position: relative;
}

.basket-header {
  padding: 1rem;
}

.title-container {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: white;
  padding: 1rem;
  border-radius: 15px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.title-container h1 {
  font-size: 1.8rem;
  color: #2d3436;
  margin: 0;
}

.count {
  color: #ff8500;
}

.animated-line {
  height: 3px;
  background: linear-gradient(90deg, #ff8500, transparent);
  margin-top: 0.5rem;
  position: relative;
  overflow: hidden;
}

.animated-line::after {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent);
  animation: shine 2s infinite;
}

@keyframes shine {
  to {
    left: 100%;
  }
}

.scrollable-content {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
}

.basket-items {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.basket-item {
  display: flex;
  background: white;
  border-radius: 15px;
  padding: 1rem;
  gap: 1rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.item-image img {
  width: 120px;
  height: 120px;
  border-radius: 10px;
  object-fit: cover;
}

.item-details {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.item-header h3 {
  font-size: 1.2rem;
  color: #2d3436;
  margin: 0 0 0.5rem 0;
}

.item-options {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.option {
  display: flex;
  align-items: center;
  gap: 0.3rem;
  font-size: 0.9rem;
  color: #636e72;
  background: #f1f2f6;
  padding: 0.3rem 0.6rem;
  border-radius: 15px;
}

.option-dot {
  width: 6px;
  height: 6px;
  background: #ff8500;
  border-radius: 50%;
}

.item-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 1rem;
}

.quantity-controls {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: #f1f2f6;
  padding: 0.5rem;
  border-radius: 25px;
}

.quantity-btn {
  background: none;
  border: none;
  padding: 0.3rem;
  cursor: pointer;
  transition: transform 0.2s;
}

.quantity-btn:active {
  transform: scale(0.95);
}

.quantity {
  font-size: 1.2rem;
  font-weight: 600;
  color: #2d3436;
  min-width: 2rem;
  text-align: center;
}

.price {
  font-size: 1.3rem;
  font-weight: 700;
  color: #ff8500;
}

.fixed-bottom {
  position: sticky;
  bottom: 0;
  background: white;
  padding: 1rem;
  border-radius: 15px 15px 0 0;
  box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
}

.basket-summary {
  margin-bottom: 1rem;
}

.summary-content {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.summary-item {
  display: flex;
  justify-content: space-between;
  color: #636e72;
}

.summary-total {
  display: flex;
  justify-content: space-between;
  font-size: 1.2rem;
  font-weight: 700;
  color: #2d3436;
  padding-top: 0.5rem;
  border-top: 1px solid #f1f2f6;
}

.basket-footer {
  display: flex;
  gap: 1rem;
}

.back-btn, .checkout-btn {
  flex: 1;
  border: none;
  padding: 1rem;
  border-radius: 10px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.back-btn {
  background: white;
  border: 2px solid #ff8500;
}

.checkout-btn {
  background: linear-gradient(135deg, #ff8500, #ff6b00);
  color: white;
}

.btn-content {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.btn-shine {
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(255,255,255,0.2) 0%, transparent 70%);
  transform: rotate(45deg);
  transition: 0.3s;
}

.back-btn:hover .btn-shine,
.checkout-btn:hover .btn-shine {
  transform: rotate(45deg) translate(50%, 50%);
}

.separator {
  width: 2px;
  height: 20px;
  background: rgba(255,255,255,0.3);
  margin: 0 1rem;
}

/* Transitions */
.list-enter-active,
.list-leave-active {
  transition: all 0.3s ease;
}

.list-enter-from,
.list-leave-to {
  opacity: 0;
  transform: translateX(-30px);
}

/* Custom Scrollbar */
.custom-scrollbar::-webkit-scrollbar {
  width: 8px;
}

.custom-scrollbar::-webkit-scrollbar-track {
  background: #f1f2f6;
  border-radius: 4px;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
  background: #ff8500;
  border-radius: 4px;
}

.custom-scrollbar::-webkit-scrollbar-thumb:hover {
  background: #ff6b00;
}
</style>